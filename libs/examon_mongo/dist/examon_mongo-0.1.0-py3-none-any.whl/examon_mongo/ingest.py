from examon_pcep_package import *
from examon_core.examon_in_memory_db import ExamonInMemoryDatabase
from .documents.question import Question
from .documents.metrics import Metrics


class Ingest:
    @staticmethod
    def run():
        inmemory_models = ExamonInMemoryDatabase.load()
        print(f'Ingesting {len(inmemory_models)} questions')
        for inmemory_model in inmemory_models:
            question = Question(
                unique_id=inmemory_model.unique_id,
                internal_id=inmemory_model.internal_id,
                function_src=inmemory_model.function_src,
                repository=inmemory_model.repository,
                hints=inmemory_model.hints,
                print_logs=inmemory_model.print_logs,
                tags=inmemory_model.tags,
                metrics=Metrics(
                    no_of_functions=inmemory_model.metrics.no_of_functions,
                    loc=inmemory_model.metrics.loc,
                    lloc=inmemory_model.metrics.lloc,
                    sloc=inmemory_model.metrics.sloc,
                    difficulty=inmemory_model.metrics.difficulty,
                    categorised_difficulty=inmemory_model.metrics.categorised_difficulty,
                    imports=inmemory_model.metrics.imports,
                    calls=inmemory_model.metrics.calls
                )
            )
            question.save()
